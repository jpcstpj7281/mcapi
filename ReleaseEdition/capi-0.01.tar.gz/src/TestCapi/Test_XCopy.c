#include <windows.h>
#include "capiglobal.h"

