#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "Testapi.h"

#include "CapiGlobal.h"
#include "ApiHook.h"
#include <iostream.h>

extern void Test_Stack();
extern void Test_Queue();
extern void Test_DeQue();
extern void Test_SortTable();

extern void Test_SingleList();
extern void Test_DoubleList();
extern void Test_BlockList();

extern void Test_HashTable();
extern void Test_HashList();

extern void Test_BinTree();
extern void Test_RBTree();
extern void Test_AVLTree();

extern void Test_HashRBTree();
extern void Test_HashAVLTree();

extern void Test_MTree();

extern void Test_WithSTL();

extern void Test_SpList();
extern void Test_DSpaceList();


void main(int argc, char *argv[])
{
//    TMemHookInit();
//    TCheckMemory    mem;

	if ( TestCase_Init() != CAPI_SUCCESS )
	{
		return;
	}

    TestManager manager(NULL);

    manager.RunTestCase();

	TestCase_Run();

	TestCase_Close();
    
//    mem.TCheckMemAll();

//    atexit(TMemHookClose);

    printf("Test Finished.\n");
}



