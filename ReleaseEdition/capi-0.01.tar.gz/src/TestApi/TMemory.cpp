/*
 * Copyright (c) 2006-2008
 * Author: Weiming Zhou
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capiglobal.h"
#include "TMemory.h"
#include "TestApi_Assert.h"
#include "ApiHook.h"

THashTable * TCheckMemory::m_pMemTable = NULL;

typedef struct MEMNODE_st{
    DWORD           dwAddr;
    DWORD           dwRetAddr;
    unsigned int    uSize;
    unsigned int    uLine;
    char    *       pszFileName;
} MEMNODE;


UINT HashMemNode(void *pKey, UINT uBucketCount)
{
    MEMNODE *pNode = (MEMNODE *)pKey;
    return (pNode->dwAddr % uBucketCount);
}

int MemNodeCompare(void *p1, void *p2)
{
    MEMNODE *pNode1;
    pNode1 = (MEMNODE *)p1;

    if ( pNode1->dwAddr == (DWORD)p2 )
    {
        return 0;
    }
    else if ( pNode1->dwAddr > (DWORD)p2 )
    {
        return 1;
    }
    else
    {
        return -1;
    }
}

void MemNodeDestroy(void *p)
{
    MEMNODE *pNode = (MEMNODE *)p;
    if ( pNode != NULL )
    {
        delete [] pNode->pszFileName;
        delete pNode;
    }
}


TCheckMemory::TCheckMemory()
{
    INT nRet;
    m_pMemTable = new THashTable;
    nRet = m_pMemTable->Create(TCHECKMEMORY_DEFAULT_HASHTABLE_SIZE, HashMemNode, 
        MemNodeCompare, MemNodeDestroy);
    assertTrue( nRet == CAPI_SUCCESS );
}

TCheckMemory::TCheckMemory(UINT uBucketCount)
{
    INT nRet;
    m_pMemTable = new THashTable;
    nRet = m_pMemTable->Create(uBucketCount, HashMemNode, 
        MemNodeCompare, MemNodeDestroy);
    assertTrue( nRet == CAPI_SUCCESS );
}



void *Tmalloc_dbg(size_t size, char *pszFile, unsigned int uLine)
{
    char *pAddr;
    DWORD dwRetAddr = 0;

    __asm {
        mov eax, dword ptr [ebp+4]
        mov dwRetAddr, eax
    }
    
    pAddr = new char[size+sizeof(UINT)];

    *(UINT *)(pAddr+size) = MEM_CHECK_FLAG;
    
    MEMNODE *pNode = NULL;
    
    pNode = new MEMNODE;

    pNode->dwAddr = (DWORD)pAddr;
    pNode->uSize = size;
    pNode->dwRetAddr = dwRetAddr;
    pNode->pszFileName = new char[strlen(pszFile)+1];
    strcpy(pNode->pszFileName, pszFile);
    pNode->uLine = uLine;

    if ( TCheckMemory::m_pMemTable != NULL )
    {
        (void)TCheckMemory::m_pMemTable->Insert(pNode);
    }
    
    return (void *)pAddr;
}

void Tfree_dbg(void *p, char *pszFile, UINT uLine)
{
    MEMNODE *pNode = NULL;

	if ( TCheckMemory::m_pMemTable != NULL )
	{
		pNode = (MEMNODE *)TCheckMemory::m_pMemTable->Find( p, HashInt );

		if ( pNode != NULL)
		{
			char *psz = (char *)pNode->dwAddr;
			UINT *pTail = (UINT *)(psz + pNode->uSize);
			if ( *pTail != MEM_CHECK_FLAG )
			{
				char msg[1024];
				sprintf(msg, "Memory overrun at 0x%x\n\t malloc position: "
						"File:%s, Line:%d\n \tfree position: File:%s, Line:%d\n", 
				  pNode->dwAddr, pNode->pszFileName, pNode->uLine, pszFile, uLine);
				printf(msg);
			}
			(void)TCheckMemory::m_pMemTable->Delete((void *)psz, HashInt);
		}
		else
		{
			printf("Try to free a undefined memeory not alloced by malloc().\n"
				"File:%s, Line:%d.\n", pszFile, uLine);
		}
	}
	delete [] (char *)p;
}

void *Tcalloc_dbg(size_t num, size_t size, char *pszFile, UINT uLine)
{
    return Tmalloc_dbg(num * size, pszFile, uLine);
}

void *Trealloc_dbg(void *memblock, size_t size, char *pszFile, UINT uLine)
{
    MEMNODE *pNode;
    DWORD dwRetAddr = 0;

    __asm {
        mov eax, dword ptr [ebp+4]
        mov dwRetAddr, eax
    }
    
    if ( TCheckMemory::m_pMemTable != NULL )
    {
        pNode = (MEMNODE *)TCheckMemory::m_pMemTable->Find(memblock, HashInt);
        if ( pNode != NULL)
        {
            MEMNODE *pNewNode;

            char *pAddr = new char[size+sizeof(UINT)];

            memcpy(pAddr, memblock, pNode->uSize);
            Tfree(memblock);

            *(UINT *)(pAddr+size) = MEM_CHECK_FLAG;

            pNewNode = new MEMNODE;

            pNewNode->dwAddr = (DWORD)pAddr;
            pNewNode->uSize = size;
            pNewNode->dwRetAddr = dwRetAddr;
            pNewNode->pszFileName = pszFile;
            pNewNode->uLine = uLine;
        
            (void)TCheckMemory::m_pMemTable->Insert(pNewNode);

            return pAddr;
        }
    }
    return unhooked_realloc(memblock, size);
}

char *Tstrdup_dbg(const char *strSource, char *pszFile, UINT uLine)
{
    char *psz = (char *)Tmalloc_dbg(strlen(strSource)+1, pszFile, uLine);
    strcpy(psz, strSource);
    return psz;
}

wchar_t *Twcsdup_dbg(const wchar_t *strSource, char *pszFile, UINT uLine)
{
    wchar_t *psz = (wchar_t *)Tmalloc_dbg(wcslen(strSource)+2, pszFile, uLine);
    (void)wcscpy(psz, strSource);
    return psz;
}


void *Tmalloc(size_t size)
{
    char *pAddr;
    DWORD dwRetAddr = 0;

    __asm {
        mov eax, dword ptr [ebp+4]
        mov dwRetAddr, eax
    }
    
    pAddr = new char[size+sizeof(UINT)];

    assertTrue( pAddr != NULL);

    *(UINT *)(pAddr+size) = MEM_CHECK_FLAG;
    
    MEMNODE *pNode = NULL;
    
    pNode = new MEMNODE;

    pNode->dwAddr = (DWORD)pAddr;
    pNode->uSize = size;
    pNode->dwRetAddr = dwRetAddr;
    pNode->pszFileName = NULL;
    pNode->uLine = 0;

    if (TCheckMemory::m_pMemTable != NULL )
    {
        (void)TCheckMemory::m_pMemTable->Insert(pNode);
    }
    
    return (void *)pAddr;
}


void *Trealloc(void *p, size_t size)
{
    MEMNODE *pNode;
    DWORD dwRetAddr = 0;

    __asm {
        mov eax, dword ptr [ebp+4]
        mov dwRetAddr, eax
    }
    
    if ( TCheckMemory::m_pMemTable != NULL )
    {
        pNode = (MEMNODE *)TCheckMemory::m_pMemTable->Find( p, HashInt );
        if ( pNode != NULL)
        {
            MEMNODE *pNewNode;

            char *pAddr = new char[size+sizeof(UINT)];

            (void)memcpy(pAddr, p, pNode->uSize);
            Tfree(p);

            *(UINT *)(pAddr+size) = MEM_CHECK_FLAG;

            pNewNode = new MEMNODE;

            pNewNode->dwAddr = (DWORD)pAddr;
            pNewNode->uSize = size;
            pNewNode->dwRetAddr = dwRetAddr;
            pNewNode->pszFileName = NULL;
            pNewNode->uLine = 0;
        
            (void)TCheckMemory::m_pMemTable->Insert(pNewNode);

            return pAddr;
        }
    }
    return unhooked_realloc(p, size);
}

void Tfree( void *p)
{
    MEMNODE *pNode;
    if ( TCheckMemory::m_pMemTable != NULL )
    {
        pNode = (MEMNODE *)TCheckMemory::m_pMemTable->Find( p, HashInt );
        if ( pNode != NULL)
        {
            char *psz = (char *)pNode->dwAddr;
            UINT *pTail = (UINT *)(psz + pNode->uSize);
            if ( *pTail != MEM_CHECK_FLAG )
            {
                char msg[1024];
                sprintf(msg, "Memory overrun at 0x%x\n\t  position: "
                        "File:%s, Line:%d, Return Address: 0x%x\n", pNode->dwAddr, 
                        pNode->pszFileName, pNode->uLine, pNode->dwRetAddr);
                printf(msg);
            }
            (void)TCheckMemory::m_pMemTable->Delete((void *)psz, HashInt);
        }
        else
        {
            printf("Try to free a unhooked memeory not alloced by Tmalloc().\n");
        }
    }
    delete [] (char *)p;
}


void TCheckMemory::TCheckMemoryLeak()
{
    UINT    uNodeCount;
    MEMNODE *pNode;
    char msg[1024];

    uNodeCount = TCheckMemory::m_pMemTable->GetNodeCount();
    if ( uNodeCount == 0 )
    {
        return;
    }

	TCheckMemory::m_pMemTable->LockHashTable();

    TCheckMemory::m_pMemTable->EnumBegin();
    while( (pNode = (MEMNODE *)TCheckMemory::m_pMemTable->EnumNext()) != NULL )
    {
        sprintf(msg, "Memory leak at 0x%x\n\t malloc() position: "
                     "File:%s, Line:%d\n",
                      pNode->dwAddr, pNode->pszFileName, pNode->uLine);
        printf(msg);
    }

	TCheckMemory::m_pMemTable->UnlockHashTable();

    sprintf(msg, "TCheckMemoryLeak(): Total memory leak count: %d\n", 
        uNodeCount);
    printf(msg);
}

void TCheckMemory::TCheckMemoryOverrun()
{
    UINT    uNodeCount;
    UINT    uOverRunCount;
    MEMNODE *pNode;
    char msg[1024];

    uNodeCount = TCheckMemory::m_pMemTable->GetNodeCount();
    if ( uNodeCount == 0 )
    {
        return;
    }
    uOverRunCount = 0;

	TCheckMemory::m_pMemTable->LockHashTable();

    TCheckMemory::m_pMemTable->EnumBegin();
    while( (pNode = (MEMNODE *)TCheckMemory::m_pMemTable->EnumNext()) != NULL )
    {
        char *psz = (char *)pNode->dwAddr;
        UINT *pTail = (UINT *)(psz + pNode->uSize);
        if (  *pTail != MEM_CHECK_FLAG )
        {
            sprintf(msg, "Memory overrun at 0x%x\n\t malloc() position: "
                    "File:%s, Line:%d\n", 
                pNode->dwAddr, pNode->pszFileName, pNode->uLine);
            printf(msg);
            uOverRunCount += 1;
        }
    }
	TCheckMemory::m_pMemTable->UnlockHashTable();
    sprintf(msg, "TCheckMemory(): Total memory overrun count: %d\n", 
        uOverRunCount);
    printf(msg);
}

void TCheckMemory::TCheckMemAll()
{
    UINT    uNodeCount;
    UINT    uOverRunCount;
    MEMNODE *pNode;
    char msg[1024];

    uNodeCount = TCheckMemory::m_pMemTable->GetNodeCount();
    if ( uNodeCount == 0 )
    {
        return;
    }
    uOverRunCount = 0;
	TCheckMemory::m_pMemTable->LockHashTable();
    TCheckMemory::m_pMemTable->EnumBegin();
    while ((pNode = (MEMNODE *)TCheckMemory::m_pMemTable->EnumNext()) != NULL)
    {
        char *psz = (char *)pNode->dwAddr;
        UINT *pTail = (UINT *)(psz + pNode->uSize);
        if ( *pTail != MEM_CHECK_FLAG )
        {
            sprintf(msg, "Memory overrun at 0x%x\n\t malloc() position: "
                "File:%s, Line:%d, Func Address:0x%x\n", 
                pNode->dwAddr, pNode->pszFileName, pNode->uLine, 
                pNode->dwRetAddr);
            printf(msg);
            uOverRunCount += 1;
        }
        sprintf(msg, "Memory leak at 0x%x\n\t malloc() position: "
                     "File:%s, Line:%d, Return Address:0x%x\n",
                     pNode->dwAddr, pNode->pszFileName, pNode->uLine,
                     pNode->dwRetAddr);
        printf(msg);
    }
	TCheckMemory::m_pMemTable->UnlockHashTable();


    sprintf(msg, "TCheckMemory(): Total memory leak count: %d, "
        "memory overrun count: %d\n", 
        uNodeCount, uOverRunCount);
    printf(msg);
}


TCheckMemory::~TCheckMemory()
{
    if ( m_pMemTable != NULL )
    {
        delete m_pMemTable;
        m_pMemTable = NULL;
    }
}


#define             MAX_MEMHOOK_FUNCTIONS   32
static HANDLE       g_hHook = NULL;
static HANDLE		g_hLock = NULL;

void TMemHookInit()
{
    g_hHook = ApiHook_Init(MAX_MEMHOOK_FUNCTIONS);
    (void)ApiHook_SetByAddr(g_hHook, (DWORD)free, (DWORD)Tfree);   
    (void)ApiHook_SetByAddr(g_hHook, (DWORD)malloc, (DWORD)Tmalloc);   
    (void)ApiHook_SetByAddr(g_hHook, (DWORD)realloc, (DWORD)Trealloc);  
	g_hLock = LockCreate();
}

void *unhooked_malloc(size_t size)
{
    void *pAddr;
	Lock(g_hLock);
    if ( g_hHook != NULL )
    {
        (void)ApiHook_UnSetByAddr(g_hHook, (DWORD)malloc);
        pAddr = malloc(size);
        (void)ApiHook_SetByAddr(g_hHook, (DWORD)malloc, (DWORD)Tmalloc); 
    }
    else
    {
        pAddr = malloc(size);
    }
	Unlock(g_hLock);
    return pAddr;
}

void *unhooked_realloc(void *p, size_t size)
{
    void *pAddr;
	Lock(g_hLock);
    if ( g_hHook != NULL )
    {
        (void)ApiHook_UnSetByAddr(g_hHook, (DWORD)realloc);
        pAddr = realloc(p, size);
        (void)ApiHook_SetByAddr(g_hHook, (DWORD)realloc, (DWORD)Trealloc); 
    }
    else
    {
        pAddr = realloc(p, size);
    }
	Unlock(g_hLock);
    return pAddr;
}

void unhooked_free(void *p)
{
	Lock(g_hLock);
    if ( g_hHook != NULL )
    {
        (void)ApiHook_UnSetByAddr(g_hHook, (DWORD)free);
        free(p);
        (void)ApiHook_SetByAddr(g_hHook, (DWORD)free, (DWORD)Tfree);   
    }
    else
    {
        free(p);
    }
	Unlock(g_hLock);
}

void TMemHookClose()
{
	Lock(g_hLock);
    (void)ApiHook_Close(g_hHook);
	g_hHook = NULL;
	Unlock(g_hLock);
}

