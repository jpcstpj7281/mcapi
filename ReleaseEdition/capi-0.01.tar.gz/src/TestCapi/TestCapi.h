//
// capitest.h
// capitest golbal definition.
//
#ifndef __CAPITEST_H__
#define __CAPITEST_H__

#define		FREE_MEM_FLAG	0xdddddddd
#define		NEW_MEM_FLAG	0xcdcdcdcd


#endif // __CAPITEST_H__
