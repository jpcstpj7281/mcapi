 /* 
 *	Queue.h
 *
 *	DESCRIPTION
 *		Interface to a generic Queue type.
 *
 *	HISTORY
 *		09-19-2004	create by zhouweiming.
 *
 */
#ifndef __DEQUE_H__
#define __DEQUE_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef DEQUEBLOCK_st {
	UINT uHead;
	UINT uTail;
	UINT uMapPos;
	void **pData;
} DEQUEBLOCK;

typedef struct DEQUE_st {
	DEQUEBLOCK **ppMap;
	DEQUEBLOCK First;
	DEQUEBLOCK Last;
	UINT uMapSize;
	UINT uBlockSize;
} DEQUE;


DEQUE *	DeQue_Create(UINT uMapSize, UINT uBlockSize);
void	DeQue_Destroy( DEQUE *pQue, DESTROYFUNC DestroyFunc );

INT	    DeQue_InsertTail( DEQUE *pQue, void *pData );

void *  DeQue_PopHead(DEQUE *pQue);

#ifdef __cplusplus
}
#endif

#endif /* __DEQUE_H__ */
