/*
 * Copyright (c) 2006-2008
 * Author: Weiming Zhou
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  
 */

#include <windows.h>
#include <stdio.h>

void CopyCurrentDir( char *pszSrcDir, char *pszTargeDir, BOOL bOverWrite );

/**	��һ��Ŀ¼����Ŀ¼�µ������ļ����Ƶ�����һ��Ŀ¼��

	@param	char *pszSrcDir - Ҫ������ԴĿ¼	
	@param	char *pszTargeDir - Ŀ��Ŀ¼	
	@param	BOOL bOverWrite - ���Ǳ�־��FALSE��ʾ����	
	@return	void - ��	
*/
void Xcopy( char *pszSrcDir, char *pszTargeDir, BOOL bOverWrite )
{
    char            szBaseSearch[MAX_PATH];
    char            szCurrentPath[MAX_PATH];
    HANDLE          hFindFile;
    WIN32_FIND_DATA FindData;
    
    memset( szCurrentPath, 0, MAX_PATH );
    GetCurrentDirectory( MAX_PATH, szCurrentPath );
    
    sprintf( szBaseSearch, "%s\\*.*", pszSrcDir );
    
    hFindFile = FindFirstFile( szBaseSearch, &FindData );
    if ( hFindFile == INVALID_HANDLE_VALUE ) {
        return;
    }
    do {
        CreateDirectory( pszTargeDir, NULL );
        if (	!strcmp( FindData.cFileName, "." ) ||
            !strcmp( FindData.cFileName, ".." )) {
            // skip . and ..
            continue;
        }
        if ( FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
            // a directory
            char	szBaseDir[MAX_PATH];
            char	szTargeDir[MAX_PATH];
            
            sprintf( szBaseDir, "%s\\%s", szCurrentPath, FindData.cFileName );
            
            SetCurrentDirectory( szBaseDir );
            
            _fullpath( szTargeDir, pszTargeDir, MAX_PATH );
            sprintf( szTargeDir, "%s\\%s", FindData.cFileName );
            
            Xcopy( szBaseDir, szTargeDir, bOverWrite );	
            
            SetCurrentDirectory( szCurrentPath );
        }
    } while ( FindNextFile( hFindFile, &FindData ));
    FindClose( hFindFile );
    
    CopyCurrentDir( pszSrcDir, pszTargeDir, bOverWrite );
}


/**	��һ��Ŀ¼�µ������ļ�����������һ��Ŀ¼��

	@param	char *pszSrcFile - Ҫ������Ŀ¼	
	@param	char *pszTargeFile - Ŀ���ļ���Ŀ¼	
	@param	BOOL bOverWrite - �Ƿ񸲸ǵı�־��ΪFALSE��ʾ���ǵ�ԭ���ļ�	
	@return	void - ��	
*/
void CopyCurrentDir( char *pszSrcDir, char *pszTargeDir, BOOL bOverWrite )
{
    char            szBaseSearch[MAX_PATH];
    HANDLE          hFindFile;
    WIN32_FIND_DATA FindData;
    
    sprintf( szBaseSearch, "%s", pszSrcDir );
    hFindFile = FindFirstFile( szBaseSearch, &FindData );
    if ( hFindFile == INVALID_HANDLE_VALUE ) {
        return;
    }
    do {
        CreateDirectory( pszTargeDir, NULL );
        if (	!strcmp( FindData.cFileName, "." ) ||
            !strcmp( FindData.cFileName, ".." )) {
            // skip . and ..
            continue;
        }
        if ( FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
            // a directory
            continue;
        }
        else {
            // plain file
            char	szSrcDir[MAX_PATH];
            char	szTargeDir[MAX_PATH];
            
            sprintf( szSrcDir, "%s", FindData.cFileName );
            sprintf( szTargeDir, "%s\\%s", pszTargeDir, FindData.cFileName );
            
            CopyFile( szSrcDir, szTargeDir, bOverWrite );
        }
    } while ( FindNextFile( hFindFile, &FindData ));
    FindClose( hFindFile );
}