/*
 * Copyright (c) 2006-2008
 * Author: Weiming Zhou
 *
 * Permission to use, copy, modify, distribute and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided that the above copyright notice appear in all copies and
 * that both that copyright notice and this permission notice appear
 * in supporting documentation.  
 */
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include "CapiGlobal.h"
#include "TestApi.h"
#include "THashTable.h"

THashTable::THashTable()
{
    m_uBucketCount = DEFAULT_HASHTABLE_SIZE;
    m_HashFunc = NULL;
    m_CompareFunc = NULL;
    m_DestroyFunc = NULL;
    m_uNodeCount = 0;
    m_uCurBucketNo = 0;
    m_pCurEntry = NULL;
    m_ppBucket = NULL;
}

THashTable::THashTable( UINT uBucketCount, 
                       HASHFUNC HashFunc, 
                       COMPAREFUNC CompareFunc, 
                       DESTROYFUNC DestroyFunc)
{
    m_uBucketCount = uBucketCount;
    m_HashFunc = HashFunc;
    m_CompareFunc = CompareFunc;
    m_DestroyFunc = DestroyFunc;
    m_uNodeCount = 0;
    m_uCurBucketNo = 0;
    m_pCurEntry = NULL;
    m_ppBucket = NULL;
}


THashTable::~THashTable()
{
    SINGLENODE  *pNode;
    SINGLENODE  *pFreeNode;
    UINT i;

    if ( m_ppBucket != NULL )
    {
        for ( i = 0; i < m_uBucketCount; i++ ) 
        {
            pNode = m_ppBucket[i];
            while ( pNode != NULL )
            {
                if ( m_DestroyFunc != NULL )
                {
                    (*m_DestroyFunc)(pNode->pData);
                }
                pFreeNode = pNode;
                pNode = pNode->pNext;
                delete pFreeNode;
            }
        }
        char *psz = (char *)m_ppBucket;
        delete[] psz;

        /* ��m_ppbucket��ɿ�ָ���Ա����ϣ��������ʹ��ʱ����ڴ�й© */
        m_ppBucket = NULL;
    }
}


INT THashTable::Create()
{
    if ( m_uBucketCount == 0 )
    {
        return CAPI_FAILED;
    }

    char *psz = new char[sizeof(SINGLENODE *) * m_uBucketCount];
    m_ppBucket = (SINGLENODE **)psz;

    memset(m_ppBucket, 0, m_uBucketCount * sizeof(SINGLENODE *));
	m_hLock = LockCreate();

    return CAPI_SUCCESS;
}

INT THashTable::Create(UINT uBucketCount, HASHFUNC HashFunc,
                     COMPAREFUNC CompareFunc,
                     DESTROYFUNC DestroyFunc )
{
    if ( uBucketCount == 0 )
    {
        return CAPI_FAILED;
    }

    char *psz = new char[sizeof(SINGLENODE *) * uBucketCount];
    m_ppBucket = (SINGLENODE **)psz;

    memset(m_ppBucket, 0, uBucketCount * sizeof(SINGLENODE *));

    m_uBucketCount = uBucketCount;

    m_HashFunc = HashFunc;
    m_CompareFunc = CompareFunc;
    m_DestroyFunc = DestroyFunc;
	m_hLock = LockCreate();

    return CAPI_SUCCESS;
}

INT THashTable::Insert(void *pData)
{
    UINT		uIndex;
    SINGLENODE	*pNode;
    SINGLENODE	*pNewNode;

	Lock(m_hLock);
    if ( pData == NULL || m_HashFunc == NULL )
    {
		Unlock(m_hLock);
        return CAPI_FAILED;
    }

    uIndex = (*m_HashFunc)( pData, m_uBucketCount );
    pNode = m_ppBucket[uIndex];

    pNewNode = new SINGLENODE;

    /* ���½ڵ���뵽������ͷ�� */
    pNewNode->pData = pData;
    pNewNode->pNext = pNode;

    m_ppBucket[uIndex] = pNewNode;
    m_uNodeCount += 1;

	Unlock(m_hLock);
    return CAPI_SUCCESS;
}

void *  THashTable::Find(void *pData)
{
    return Find(pData, m_HashFunc);
}

void * THashTable::Find(void *pData, HASHFUNC HashFunc)
{
	UINT			uIndex;
	SINGLENODE *	pNode;

	Lock(m_hLock);
	if ( HashFunc == NULL || m_CompareFunc == NULL )
	{
		Unlock(m_hLock);
		return NULL;
	}

	uIndex = (*HashFunc)( pData, m_uBucketCount );
	pNode = m_ppBucket[uIndex];
	
	/* �� HASHTABLE �н��в��� */
	while ( pNode != NULL )
	{
		if ( (*m_CompareFunc)( pNode->pData, pData) == 0 )
		{
			/* �Ѿ��ҵ��˹ؼ��ʣ����� */
			void *pData = pNode->pData;
			Unlock(m_hLock);
			return pData;
		}
		pNode = pNode->pNext;
	}
	Unlock(m_hLock);
    return NULL;
}

INT THashTable::Delete(void *pData)
{
    return Delete(pData, m_HashFunc);
}

INT THashTable::Delete(void *pData, HASHFUNC HashFunc)
{
	UINT			uIndex;
	SINGLENODE *	pNode;
	SINGLENODE *    pPrevNode;

	Lock(m_hLock);
	if ( pData == NULL || HashFunc == NULL 
        || m_CompareFunc == NULL )
	{
		Unlock(m_hLock);
		return CAPI_FAILED;
	}

	uIndex = (*HashFunc)( pData, m_uBucketCount );
	pNode = m_ppBucket[uIndex];
    pPrevNode = pNode;

    /* �ӹ�ϣ���в��� */
    while ( pNode != NULL )
    {
        if ( (*m_CompareFunc)( pNode->pData, pData ) == 0 )
        {
            if ( pPrevNode == pNode )
            {
                m_ppBucket[uIndex] = pNode->pNext;
            }
            else
            {
                pPrevNode->pNext = pNode->pNext;
            }

            /* ɾ����Ӧ�ڵ� */
            if ( m_DestroyFunc != NULL )
            {
                (*m_DestroyFunc)(pNode->pData);
            }
            delete pNode;

            m_uNodeCount -= 1;

			Unlock(m_hLock);

            return CAPI_SUCCESS;
        }

        pPrevNode = pNode;
        pNode = pNode->pNext;
    }
	Unlock(m_hLock);
    return CAPI_FAILED;
}

UINT THashTable::GetNodeCount()
{
	UINT	 uNodeCount;
	Lock(m_hLock);
	uNodeCount = m_uNodeCount;
	Unlock(m_hLock);
    return uNodeCount;
}

UINT THashTable::GetBucketCount()
{
	UINT	 uBucketCount;
	Lock(m_hLock);
	uBucketCount = m_uBucketCount;
	Unlock(m_hLock);
    return uBucketCount;
}

void THashTable::SetHashFunc(HASHFUNC HashFunc)
{
	Lock(m_hLock);
    m_HashFunc = HashFunc;
	Unlock(m_hLock);
}

void THashTable::SetCompareFunc(COMPAREFUNC CompareFunc)
{
	Lock(m_hLock);
    m_CompareFunc = CompareFunc;
	Unlock(m_hLock);
}

void THashTable::SetDestroyFunc(DESTROYFUNC DestroyFunc)
{
	Lock(m_hLock);
    m_DestroyFunc = DestroyFunc;
	Unlock(m_hLock);
}

void THashTable::EnumBegin()
{
    m_uCurBucketNo = 0;
    m_pCurEntry = m_ppBucket[0];
}

void * THashTable::EnumNext()
{
    void *pData;

	while ( m_pCurEntry == NULL )
	{
		m_uCurBucketNo += 1;
		if ( m_uCurBucketNo >= m_uBucketCount )
		{
			return NULL;
		}
		m_pCurEntry = m_ppBucket[m_uCurBucketNo];
	}

	pData = m_pCurEntry->pData;

    m_pCurEntry = m_pCurEntry->pNext;

    return pData;
}

void THashTable::LockHashTable()
{
	Lock(m_hLock);
}

void THashTable::UnlockHashTable()
{
	Unlock(m_hLock);
}
