#include <windows.h>
#include <stdio.h>
#include <process.h>
#include "CapiGlobal.h"
#include "Testapi.h"
#include "BinTree.h"
#include "RBTree.h"
#include "MTask.h"
#include "MTree.h"

typedef struct MTREE_st {
    RBTREE      *pRBTree;
    RBTREENODE  *pCursor;
    MTASK       *pMTask;
} MTREE;

typedef MTREE   MTree;

INT DRV_MTree_Create(INT i);
INT DRV_MTree_Destroy(INT i);
INT DRV_MTree_Insert(INT i);
INT DRV_MTree_Delete(INT i);

void *StrCopy(void *psz)
{
    if ( psz != NULL )
    {
        return (void *)strdup((char *)psz);
    }
    else
    {
        return NULL;
    }
}

void MTree_TraverseTask(LPVOID args)
{
    HANDLE   hTree = (HANDLE)args;
    MTree_EnterTask(hTree);
    for ( ; ; )
    {
        if ( MTree_GetExitFlag(hTree) == MTASK_EXIT )
        {
            break;
        }
        void *p;
        MTree_EnumBegin(hTree);
        while ( (p = MTree_EnumNextCopy(hTree, StrCopy)) != NULL )
        {
 //           printf("%s", p);
            free(p);
        }
    }
    MTree_LeaveTask(hTree);

    return ;
}

void Test_MTree()
{
    int     i;
    for ( i = 1; i < 50; i++ )
    {
        DRV_MTree_Create(i);
        DRV_MTree_Destroy(i);
        DRV_MTree_Insert(i);
        DRV_MTree_Delete(i);
//        DRV_MTree_Find(i);
    }    

    HANDLE   hTree = MTree_Create();

    MTree_Insert(hTree, strdup("20"), StrCompare);
    MTree_Insert(hTree, strdup("21"), StrCompare);
    MTree_Insert(hTree, strdup("22"), StrCompare);
    MTree_Insert(hTree, strdup("23"), StrCompare);
    MTree_Insert(hTree, strdup("24"), StrCompare);
    MTree_Insert(hTree, strdup("25"), StrCompare);
    MTree_Insert(hTree, strdup("26"), StrCompare);
    MTree_Insert(hTree, strdup("27"), StrCompare);
    MTree_Insert(hTree, strdup("28"), StrCompare);
    MTree_Insert(hTree, strdup("29"), StrCompare);
    MTree_Insert(hTree, strdup("30"), StrCompare);
    MTree_Insert(hTree, strdup("31"), StrCompare);
    MTree_Insert(hTree, strdup("32"), StrCompare);
    MTree_Insert(hTree, strdup("33"), StrCompare);


    _beginthread(MTree_TraverseTask, 0, hTree);
    //hThread = CreateThread(NULL, 0, MTree_TraverseTask, (void *)hTree, 0, &dwId);
    
    for ( i = 0; i < 1000; i++ )
    {
        MTree_Delete(hTree, "27", StrCompare, free);
        MTree_Insert(hTree, strdup("27"), StrCompare);
    }
    Sleep(100);
    MTree_Destroy(hTree, free);
}

REGISTER_TESTFUNC(Test_MTree)

INT DRV_MTree_Create(INT i)
{
    MTREE  *pTree = NULL;
    switch( i )
    {
    case 1:
        pTree = (MTREE *)MTree_Create();
        if ( pTree != NULL
            && pTree->pRBTree->pCursor == NULL
            && pTree->pRBTree->pRoot == NULL 
            && pTree->pRBTree->uNodeCount == 0 
            && pTree->pMTask->pExitEvent != NULL 
            && pTree->pMTask->pLock != NULL 
            && pTree->pMTask->uExitFlag != MTASK_EXIT
            && pTree->pMTask->uTaskCount == 0 )
        {
        }
        else
        {
            printf("MTree_Create() ��������1ʧ��\n");
        }
        break;
    default:
        break;
    }
    MTree_Destroy(pTree, free);
    return 1;
}

INT DRV_MTree_Destroy(INT i)
{
    MTree  *pTree = NULL;
    pTree = (MTREE *)MTree_Create();
    switch( i )
    {
    case 1:
        MTree_Destroy((HANDLE)pTree, free);
        break;
    default:
        MTree_Destroy((HANDLE)pTree, free);
        break;
    }
    return 1;
}

INT DRV_MTree_Insert(INT i)
{
    MTree  *pTree = NULL;
    pTree = (MTREE *)MTree_Create();
    switch( i )
    {
    case 1: /* ����1���ڵ����� */
        MTree_Insert(pTree, strdup("20"), StrCompare);
        if ( strcmp((char *)(pTree->pRBTree->pRoot->pData), "20") == 0 
            && pTree->pRBTree->pRoot->pLeft == NULL 
            && pTree->pRBTree->pRoot->pRight == NULL
            && pTree->pRBTree->pRoot->nMagic == RBTREE_COLOR_BLACK
            && pTree->pRBTree->uNodeCount == 1
            && pTree->pCursor == NULL )
        {
        }
        else
        {
            printf("MTree_Insert() ��������1, ����1���ڵ�ʧ��\n");
        }
        break;
    case 2: /* ���������ڵ����� */
        break;
    default:
        break;
    }
    MTree_Destroy(pTree, free);
    return 1;
}

INT DRV_MTree_Delete(INT i)
{
    MTREE  *pTree = NULL;
    HANDLE hTree = MTree_Create();
    pTree = (MTREE *)hTree;
    switch( i )
    {
    case 1:
        MTree_Insert(hTree, strdup("20"), StrCompare);
        MTree_Delete(hTree, "20", StrCompare, free);
        if ( pTree->pRBTree->pRoot == NULL
            && pTree->pRBTree->uNodeCount == 0
            && pTree->pCursor == NULL )
        {
        }
        else
        {
            printf("MTree_Delete() ��������1, ����1���ڵ�ʧ��\n");
        }
        break;
    default:
        break;
    }
    MTree_Destroy(pTree, free);
    return 1;
}